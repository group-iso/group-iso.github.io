import Mathlib.Geometry.Euclidean.Angle.Unoriented.RightAngle

/-!
# Pythagorean theorem

The paper's side lengths are a = dist A C, b = dist B C, c = dist A B.
The hypothesis hC states that the angle at C is a right angle.

This minimal example verifies the theorem's geometric statement using
Mathlib's Pythagorean theorem. It does not formalize the paper's
altitude-and-similarity proof step by step.
-/

namespace Pythagorean

variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]

theorem pythagorean_theorem (A B C : V)
    (hC : EuclideanGeometry.angle A C B = Real.pi / 2) :
    dist A C ^ 2 + dist B C ^ 2 = dist A B ^ 2 := by
  simpa only [pow_two] using
    ((EuclideanGeometry.dist_sq_eq_dist_sq_add_dist_sq_iff_angle_eq_pi_div_two
      A C B).2 hC).symm

end Pythagorean
