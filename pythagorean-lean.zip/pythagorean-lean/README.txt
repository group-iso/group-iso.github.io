Pythagorean theorem — minimal Lean verification

Main file: Pythagorean.lean

Statement
---------
For points A, B, C in a real inner product space, a right angle at C
implies dist A C ^ 2 + dist B C ^ 2 = dist A B ^ 2.
Thus a = dist A C, b = dist B C, and c = dist A B, as in the paper.

Reproduce
---------
With Lean's Elan toolchain manager installed, open a terminal in this
folder and run:

  lake update
  lake exe cache get Mathlib.Geometry.Euclidean.Angle.Unoriented.RightAngle
  lake env lean Pythagorean.lean

The last command succeeds silently with exit code 0 when the proof checks.
The first two commands download the pinned dependencies.

Versions
--------
Lean: 4.24.0
Mathlib: f897ebcf72cd16f89ab4577d0c826cd14afaafc7

Reference
---------
https://github.com/leanprover-community/mathlib4/blob/f897ebcf72cd16f89ab4577d0c826cd14afaafc7/Mathlib/Geometry/Euclidean/Angle/Unoriented/RightAngle.lean
